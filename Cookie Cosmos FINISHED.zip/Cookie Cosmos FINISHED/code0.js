gdjs.Start_32ScreenCode = {};
gdjs.Start_32ScreenCode.GDBackgroundObjects1= [];
gdjs.Start_32ScreenCode.GDBackgroundObjects2= [];
gdjs.Start_32ScreenCode.GDBackgroundObjects3= [];
gdjs.Start_32ScreenCode.GDGameOverTextObjects1= [];
gdjs.Start_32ScreenCode.GDGameOverTextObjects2= [];
gdjs.Start_32ScreenCode.GDGameOverTextObjects3= [];
gdjs.Start_32ScreenCode.GDAstroAnnieObjects1= [];
gdjs.Start_32ScreenCode.GDAstroAnnieObjects2= [];
gdjs.Start_32ScreenCode.GDAstroAnnieObjects3= [];
gdjs.Start_32ScreenCode.GDTitleScreenObjects1= [];
gdjs.Start_32ScreenCode.GDTitleScreenObjects2= [];
gdjs.Start_32ScreenCode.GDTitleScreenObjects3= [];
gdjs.Start_32ScreenCode.GDPlayButtonObjects1= [];
gdjs.Start_32ScreenCode.GDPlayButtonObjects2= [];
gdjs.Start_32ScreenCode.GDPlayButtonObjects3= [];
gdjs.Start_32ScreenCode.GDShotObjects1= [];
gdjs.Start_32ScreenCode.GDShotObjects2= [];
gdjs.Start_32ScreenCode.GDShotObjects3= [];
gdjs.Start_32ScreenCode.GDControllerCenterObjects1= [];
gdjs.Start_32ScreenCode.GDControllerCenterObjects2= [];
gdjs.Start_32ScreenCode.GDControllerCenterObjects3= [];
gdjs.Start_32ScreenCode.GDControllerPositionObjects1= [];
gdjs.Start_32ScreenCode.GDControllerPositionObjects2= [];
gdjs.Start_32ScreenCode.GDControllerPositionObjects3= [];
gdjs.Start_32ScreenCode.GDTouchRadiusObjects1= [];
gdjs.Start_32ScreenCode.GDTouchRadiusObjects2= [];
gdjs.Start_32ScreenCode.GDTouchRadiusObjects3= [];
gdjs.Start_32ScreenCode.GDScoreTextObjects1= [];
gdjs.Start_32ScreenCode.GDScoreTextObjects2= [];
gdjs.Start_32ScreenCode.GDScoreTextObjects3= [];
gdjs.Start_32ScreenCode.GDMouseDistanceCheckObjects1= [];
gdjs.Start_32ScreenCode.GDMouseDistanceCheckObjects2= [];
gdjs.Start_32ScreenCode.GDMouseDistanceCheckObjects3= [];
gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects1= [];
gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects2= [];
gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects3= [];
gdjs.Start_32ScreenCode.GDFenceObjects1= [];
gdjs.Start_32ScreenCode.GDFenceObjects2= [];
gdjs.Start_32ScreenCode.GDFenceObjects3= [];
gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1= [];
gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2= [];
gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects3= [];
gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1= [];
gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2= [];
gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects3= [];
gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1= [];
gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects2= [];
gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects3= [];
gdjs.Start_32ScreenCode.GDScoreTweenTargetObjects1= [];
gdjs.Start_32ScreenCode.GDScoreTweenTargetObjects2= [];
gdjs.Start_32ScreenCode.GDScoreTweenTargetObjects3= [];
gdjs.Start_32ScreenCode.GDDestroyedMeteorObjects1= [];
gdjs.Start_32ScreenCode.GDDestroyedMeteorObjects2= [];
gdjs.Start_32ScreenCode.GDDestroyedMeteorObjects3= [];
gdjs.Start_32ScreenCode.GDSoundButtonObjects1= [];
gdjs.Start_32ScreenCode.GDSoundButtonObjects2= [];
gdjs.Start_32ScreenCode.GDSoundButtonObjects3= [];
gdjs.Start_32ScreenCode.GDAnneSpawnPointObjects1= [];
gdjs.Start_32ScreenCode.GDAnneSpawnPointObjects2= [];
gdjs.Start_32ScreenCode.GDAnneSpawnPointObjects3= [];
gdjs.Start_32ScreenCode.GDRetryButtonObjects1= [];
gdjs.Start_32ScreenCode.GDRetryButtonObjects2= [];
gdjs.Start_32ScreenCode.GDRetryButtonObjects3= [];
gdjs.Start_32ScreenCode.GDChocolateChipObjects1= [];
gdjs.Start_32ScreenCode.GDChocolateChipObjects2= [];
gdjs.Start_32ScreenCode.GDChocolateChipObjects3= [];
gdjs.Start_32ScreenCode.GDDeathEffectObjects1= [];
gdjs.Start_32ScreenCode.GDDeathEffectObjects2= [];
gdjs.Start_32ScreenCode.GDDeathEffectObjects3= [];

gdjs.Start_32ScreenCode.conditionTrue_0 = {val:false};
gdjs.Start_32ScreenCode.condition0IsTrue_0 = {val:false};
gdjs.Start_32ScreenCode.condition1IsTrue_0 = {val:false};
gdjs.Start_32ScreenCode.condition2IsTrue_0 = {val:false};
gdjs.Start_32ScreenCode.condition3IsTrue_0 = {val:false};
gdjs.Start_32ScreenCode.conditionTrue_1 = {val:false};
gdjs.Start_32ScreenCode.condition0IsTrue_1 = {val:false};
gdjs.Start_32ScreenCode.condition1IsTrue_1 = {val:false};
gdjs.Start_32ScreenCode.condition2IsTrue_1 = {val:false};
gdjs.Start_32ScreenCode.condition3IsTrue_1 = {val:false};


gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDTouchRadiusObjects1Objects = Hashtable.newFrom({"TouchRadius": gdjs.Start_32ScreenCode.GDTouchRadiusObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDMouseDistanceCheckObjects1Objects = Hashtable.newFrom({"MouseDistanceCheck": gdjs.Start_32ScreenCode.GDMouseDistanceCheckObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDControllerPositionObjects2Objects = Hashtable.newFrom({"ControllerPosition": gdjs.Start_32ScreenCode.GDControllerPositionObjects2});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDControllerCenterObjects2Objects = Hashtable.newFrom({"ControllerCenter": gdjs.Start_32ScreenCode.GDControllerCenterObjects2});
gdjs.Start_32ScreenCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ControllerCenter"), gdjs.Start_32ScreenCode.GDControllerCenterObjects2);
gdjs.copyArray(gdjs.Start_32ScreenCode.GDControllerPositionObjects1, gdjs.Start_32ScreenCode.GDControllerPositionObjects2);


gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDControllerPositionObjects2Objects, gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDControllerCenterObjects2Objects, 100, true);
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDControllerCenterObjects2 */
/* Reuse gdjs.Start_32ScreenCode.GDControllerPositionObjects2 */
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDControllerPositionObjects2.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDControllerPositionObjects2[i].putAroundObject((gdjs.Start_32ScreenCode.GDControllerCenterObjects2.length !== 0 ? gdjs.Start_32ScreenCode.GDControllerCenterObjects2[0] : null), 100, (( gdjs.Start_32ScreenCode.GDControllerCenterObjects2.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDControllerCenterObjects2[0].getAngle()));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ControllerCenter"), gdjs.Start_32ScreenCode.GDControllerCenterObjects1);
{runtimeScene.getVariables().getFromIndex(0).setNumber((( gdjs.Start_32ScreenCode.GDControllerCenterObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDControllerCenterObjects1[0].getAngle()));
}}

}


};gdjs.Start_32ScreenCode.eventsList1 = function(runtimeScene) {

{


gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ControllerPosition"), gdjs.Start_32ScreenCode.GDControllerPositionObjects1);
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDControllerPositionObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDControllerPositionObjects1[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0),gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}
{ //Subevents
gdjs.Start_32ScreenCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDTouchRadiusObjects1Objects = Hashtable.newFrom({"TouchRadius": gdjs.Start_32ScreenCode.GDTouchRadiusObjects1});
gdjs.Start_32ScreenCode.eventsList2 = function(runtimeScene) {

{


gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).setNumber(2);
}}

}


{


gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).setNumber(2);
}}

}


};gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDTouchRadiusObjects1Objects = Hashtable.newFrom({"TouchRadius": gdjs.Start_32ScreenCode.GDTouchRadiusObjects1});
gdjs.Start_32ScreenCode.eventsList3 = function(runtimeScene) {

{


gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).setNumber(1);
}}

}


};gdjs.Start_32ScreenCode.eventsList4 = function(runtimeScene) {

{


gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) == 2;
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Start_32ScreenCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDPlayButtonHitBoxObjects1Objects = Hashtable.newFrom({"PlayButtonHitBox": gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDAstroAnnieObjects1Objects = Hashtable.newFrom({"AstroAnnie": gdjs.Start_32ScreenCode.GDAstroAnnieObjects1});
gdjs.Start_32ScreenCode.eventsList5 = function(runtimeScene) {

{

/* Reuse gdjs.Start_32ScreenCode.GDPlayButtonObjects1 */

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition2IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Start_32ScreenCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i].isVisible() ) {
        gdjs.Start_32ScreenCode.condition1IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDPlayButtonObjects1[k] = gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length = k;}if ( gdjs.Start_32ScreenCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i].getOpacity() == 255 ) {
        gdjs.Start_32ScreenCode.condition2IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDPlayButtonObjects1[k] = gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length = k;}}
}
if (gdjs.Start_32ScreenCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("AnneSpawnPoint"), gdjs.Start_32ScreenCode.GDAnneSpawnPointObjects1);
/* Reuse gdjs.Start_32ScreenCode.GDPlayButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.Start_32ScreenCode.GDScoreTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("TitleScreen"), gdjs.Start_32ScreenCode.GDTitleScreenObjects1);
gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length = 0;

{for(var i = 0, len = gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDTitleScreenObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDTitleScreenObjects1[i].hide();
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDAstroAnnieObjects1Objects, (( gdjs.Start_32ScreenCode.GDAnneSpawnPointObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDAnneSpawnPointObjects1[0].getPointX("")), (( gdjs.Start_32ScreenCode.GDAnneSpawnPointObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDAnneSpawnPointObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDScoreTextObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDScoreTextObjects1[i].hide(false);
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "UI");
}}

}


};gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDPlayButtonHitBoxObjects1Objects = Hashtable.newFrom({"PlayButtonHitBox": gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDAstroAnnieObjects1Objects = Hashtable.newFrom({"AstroAnnie": gdjs.Start_32ScreenCode.GDAstroAnnieObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDFenceObjects1Objects = Hashtable.newFrom({"Fence": gdjs.Start_32ScreenCode.GDFenceObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDFenceObjects1Objects = Hashtable.newFrom({"Fence": gdjs.Start_32ScreenCode.GDFenceObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDShotObjects1Objects = Hashtable.newFrom({"Shot": gdjs.Start_32ScreenCode.GDShotObjects1});
gdjs.Start_32ScreenCode.eventsList6 = function(runtimeScene) {

{


{
/* Reuse gdjs.Start_32ScreenCode.GDAstroAnnieObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Shot"), gdjs.Start_32ScreenCode.GDShotObjects1);
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].getBehavior("FireBullet").Fire((gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].getPointX("Bullet")), (gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].getPointY("Bullet")), gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDShotObjects1Objects, 0, 600, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "BlastFired.wav", false, 40, 1);
}}

}


};gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDLargeCookieClusterObjects1ObjectsGDgdjs_46Start_9532ScreenCode_46GDMediumCookieClusterObjects1ObjectsGDgdjs_46Start_9532ScreenCode_46GDSmallCookieClusterObjects1Objects = Hashtable.newFrom({"LargeCookieCluster": gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1, "MediumCookieCluster": gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1, "SmallCookieCluster": gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1});
gdjs.Start_32ScreenCode.eventsList7 = function(runtimeScene) {

{


{
gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1.length = 0;

gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1.length = 0;

gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDLargeCookieClusterObjects1ObjectsGDgdjs_46Start_9532ScreenCode_46GDMediumCookieClusterObjects1ObjectsGDgdjs_46Start_9532ScreenCode_46GDSmallCookieClusterObjects1Objects, "LargeCookieCluster", 1200, gdjs.random(800), "");
}}

}


};gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDMediumCookieClusterObjects1Objects = Hashtable.newFrom({"MediumCookieCluster": gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1});
gdjs.Start_32ScreenCode.eventsList8 = function(runtimeScene) {

{


{
gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDMediumCookieClusterObjects1Objects, 1200, gdjs.random(800), "");
}}

}


};gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDSmallCookieClusterObjects1Objects = Hashtable.newFrom({"SmallCookieCluster": gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1});
gdjs.Start_32ScreenCode.eventsList9 = function(runtimeScene) {

{


{
gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDSmallCookieClusterObjects1Objects, 1200, gdjs.random(800), "");
}}

}


};gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDLargeCookieClusterObjects1ObjectsGDgdjs_46Start_9532ScreenCode_46GDMediumCookieClusterObjects1ObjectsGDgdjs_46Start_9532ScreenCode_46GDSmallCookieClusterObjects1Objects = Hashtable.newFrom({"LargeCookieCluster": gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1, "MediumCookieCluster": gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1, "SmallCookieCluster": gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDShotObjects1Objects = Hashtable.newFrom({"Shot": gdjs.Start_32ScreenCode.GDShotObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDDestroyedMeteorObjects1Objects = Hashtable.newFrom({"DestroyedMeteor": gdjs.Start_32ScreenCode.GDDestroyedMeteorObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDChocolateChipObjects2Objects = Hashtable.newFrom({"ChocolateChip": gdjs.Start_32ScreenCode.GDChocolateChipObjects2});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDChocolateChipObjects2Objects = Hashtable.newFrom({"ChocolateChip": gdjs.Start_32ScreenCode.GDChocolateChipObjects2});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDChocolateChipObjects1Objects = Hashtable.newFrom({"ChocolateChip": gdjs.Start_32ScreenCode.GDChocolateChipObjects1});
gdjs.Start_32ScreenCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1, gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2);


gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2[k] = gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2.length = k;}if ( gdjs.Start_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "LargeChipGen") > gdjs.random(20);
}}
if (gdjs.Start_32ScreenCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2 */
gdjs.copyArray(gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1, gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2);

gdjs.copyArray(gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1, gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects2);

gdjs.Start_32ScreenCode.GDChocolateChipObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDChocolateChipObjects2Objects, (( gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects2.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2[0].getPointX("")) :gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2[0].getPointX("")) :gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects2[0].getPointX("")), (( gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects2.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2[0].getPointY("")) :gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2[0].getPointY("")) :gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects2[0].getPointY("")), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "LargeChipGen");
}}

}


{

gdjs.copyArray(gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1, gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2);


gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2[k] = gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2.length = k;}if ( gdjs.Start_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "MediumChipGen") > gdjs.random(35);
}}
if (gdjs.Start_32ScreenCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1, gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2);

/* Reuse gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2 */
gdjs.copyArray(gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1, gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects2);

gdjs.Start_32ScreenCode.GDChocolateChipObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDChocolateChipObjects2Objects, (( gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects2.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2[0].getPointX("")) :gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2[0].getPointX("")) :gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects2[0].getPointX("")), (( gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects2.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2[0].getPointY("")) :gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2[0].getPointY("")) :gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects2[0].getPointY("")), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "MediumChipGen");
}}

}


{

/* Reuse gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1 */

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1[k] = gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length = k;}if ( gdjs.Start_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "SmallChipGen") > gdjs.random(50);
}}
if (gdjs.Start_32ScreenCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1 */
/* Reuse gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1 */
/* Reuse gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1 */
gdjs.Start_32ScreenCode.GDChocolateChipObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDChocolateChipObjects1Objects, (( gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1[0].getPointX("")) :gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1[0].getPointX("")) :gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1[0].getPointX("")), (( gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1[0].getPointY("")) :gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1[0].getPointY("")) :gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1[0].getPointY("")), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SmallChipGen");
}}

}


};gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDAstroAnnieObjects1Objects = Hashtable.newFrom({"AstroAnnie": gdjs.Start_32ScreenCode.GDAstroAnnieObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDLargeCookieClusterObjects1ObjectsGDgdjs_46Start_9532ScreenCode_46GDMediumCookieClusterObjects1ObjectsGDgdjs_46Start_9532ScreenCode_46GDSmallCookieClusterObjects1Objects = Hashtable.newFrom({"LargeCookieCluster": gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1, "MediumCookieCluster": gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1, "SmallCookieCluster": gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDDeathEffectObjects1Objects = Hashtable.newFrom({"DeathEffect": gdjs.Start_32ScreenCode.GDDeathEffectObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDPlayButtonHitBoxObjects1Objects = Hashtable.newFrom({"PlayButtonHitBox": gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects1});
gdjs.Start_32ScreenCode.eventsList11 = function(runtimeScene) {

{

/* Reuse gdjs.Start_32ScreenCode.GDRetryButtonObjects1 */

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Start_32ScreenCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDRetryButtonObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDRetryButtonObjects1[i].getOpacity() == 255 ) {
        gdjs.Start_32ScreenCode.condition1IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDRetryButtonObjects1[k] = gdjs.Start_32ScreenCode.GDRetryButtonObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDRetryButtonObjects1.length = k;}}
if (gdjs.Start_32ScreenCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Start Screen");
}}

}


};gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDPlayButtonHitBoxObjects1Objects = Hashtable.newFrom({"PlayButtonHitBox": gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDSoundButtonObjects1Objects = Hashtable.newFrom({"SoundButton": gdjs.Start_32ScreenCode.GDSoundButtonObjects1});
gdjs.Start_32ScreenCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Start_32ScreenCode.GDSoundButtonObjects1, gdjs.Start_32ScreenCode.GDSoundButtonObjects2);


gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDSoundButtonObjects2.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDSoundButtonObjects2[i].getVariableBoolean(gdjs.Start_32ScreenCode.GDSoundButtonObjects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDSoundButtonObjects2[k] = gdjs.Start_32ScreenCode.GDSoundButtonObjects2[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDSoundButtonObjects2.length = k;}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDSoundButtonObjects2 */
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDSoundButtonObjects2.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDSoundButtonObjects2[i].setAnimation(0);
}
}{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 100);
}}

}


{

/* Reuse gdjs.Start_32ScreenCode.GDSoundButtonObjects1 */

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDSoundButtonObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDSoundButtonObjects1[i].getVariableBoolean(gdjs.Start_32ScreenCode.GDSoundButtonObjects1[i].getVariables().getFromIndex(0), true) ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDSoundButtonObjects1[k] = gdjs.Start_32ScreenCode.GDSoundButtonObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDSoundButtonObjects1.length = k;}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDSoundButtonObjects1 */
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDSoundButtonObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDSoundButtonObjects1[i].setAnimation(1);
}
}{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, 0);
}}

}


};gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDAstroAnnieObjects1Objects = Hashtable.newFrom({"AstroAnnie": gdjs.Start_32ScreenCode.GDAstroAnnieObjects1});
gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDChocolateChipObjects1Objects = Hashtable.newFrom({"ChocolateChip": gdjs.Start_32ScreenCode.GDChocolateChipObjects1});
gdjs.Start_32ScreenCode.eventsList13 = function(runtimeScene) {

{



}


{


gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("AnneSpawnPoint"), gdjs.Start_32ScreenCode.GDAnneSpawnPointObjects1);
gdjs.copyArray(runtimeScene.getObjects("ControllerCenter"), gdjs.Start_32ScreenCode.GDControllerCenterObjects1);
gdjs.copyArray(runtimeScene.getObjects("ControllerPosition"), gdjs.Start_32ScreenCode.GDControllerPositionObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fence"), gdjs.Start_32ScreenCode.GDFenceObjects1);
gdjs.copyArray(runtimeScene.getObjects("GameOverText"), gdjs.Start_32ScreenCode.GDGameOverTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayButton"), gdjs.Start_32ScreenCode.GDPlayButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayButtonHitBox"), gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("RetryButton"), gdjs.Start_32ScreenCode.GDRetryButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.Start_32ScreenCode.GDScoreTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("ScoreTweenTarget"), gdjs.Start_32ScreenCode.GDScoreTweenTargetObjects1);
gdjs.copyArray(runtimeScene.getObjects("SoundButton"), gdjs.Start_32ScreenCode.GDSoundButtonObjects1);
gdjs.Start_32ScreenCode.GDMouseDistanceCheckObjects1.length = 0;

gdjs.Start_32ScreenCode.GDTouchRadiusObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDTouchRadiusObjects1Objects, (( gdjs.Start_32ScreenCode.GDControllerCenterObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDControllerCenterObjects1[0].getPointX("")), (( gdjs.Start_32ScreenCode.GDControllerCenterObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDControllerCenterObjects1[0].getPointY("")), "UI");
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDControllerPositionObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDControllerPositionObjects1[i].setPosition((( gdjs.Start_32ScreenCode.GDControllerCenterObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDControllerCenterObjects1[0].getPointX("")),(( gdjs.Start_32ScreenCode.GDControllerCenterObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDControllerCenterObjects1[0].getPointY("")));
}
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "UI");
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDControllerCenterObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDControllerCenterObjects1[i].setOpacity(0);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDMouseDistanceCheckObjects1Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "UI", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "UI", 0), "");
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDMouseDistanceCheckObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDMouseDistanceCheckObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDFenceObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDFenceObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDAnneSpawnPointObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDAnneSpawnPointObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDScoreTweenTargetObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDScoreTweenTargetObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDRetryButtonObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDRetryButtonObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDGameOverTextObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDGameOverTextObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDTouchRadiusObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDTouchRadiusObjects1[i].setZOrder(9);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SpawnEnemy");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SpawnEnemy2");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SpawnEnemy3");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SmallChipGen");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "MediumChipGen");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "LargeChipGen");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Fire");
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDSoundButtonObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDSoundButtonObjects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDScoreTextObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDScoreTextObjects1[i].setZOrder(202);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDGameOverTextObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDGameOverTextObjects1[i].setZOrder(200);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDRetryButtonObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDRetryButtonObjects1[i].setZOrder(201);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i].getBehavior("Tween").addObjectOpacityTween("PlayButtonFadeStart", 255, "easeInOutQuad", 1000, false);
}
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "MWMedited.ogg", 0, true, 100, 1);
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("ControllerCenter"), gdjs.Start_32ScreenCode.GDControllerCenterObjects1);
gdjs.copyArray(runtimeScene.getObjects("ControllerPosition"), gdjs.Start_32ScreenCode.GDControllerPositionObjects1);
gdjs.copyArray(runtimeScene.getObjects("MouseDistanceCheck"), gdjs.Start_32ScreenCode.GDMouseDistanceCheckObjects1);
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDMouseDistanceCheckObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDMouseDistanceCheckObjects1[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0),gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDControllerCenterObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDControllerCenterObjects1[i].rotateTowardPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), 0, runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(1).setNumber((( gdjs.Start_32ScreenCode.GDControllerCenterObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDControllerCenterObjects1[0].getDistanceToObject((gdjs.Start_32ScreenCode.GDControllerPositionObjects1.length !== 0 ? gdjs.Start_32ScreenCode.GDControllerPositionObjects1[0] : null))));
}}

}


{


gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) == 2;
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Start_32ScreenCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ControllerCenter"), gdjs.Start_32ScreenCode.GDControllerCenterObjects1);
gdjs.copyArray(runtimeScene.getObjects("ControllerPosition"), gdjs.Start_32ScreenCode.GDControllerPositionObjects1);
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDControllerPositionObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDControllerPositionObjects1[i].setPosition((gdjs.Start_32ScreenCode.GDControllerPositionObjects1[i].getPointX("")),(gdjs.Start_32ScreenCode.GDControllerPositionObjects1[i].getPointY("")));
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDControllerPositionObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDControllerPositionObjects1[i].getBehavior("Tween").addObjectPositionTween("BackToCenter", (( gdjs.Start_32ScreenCode.GDControllerCenterObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDControllerCenterObjects1[0].getPointX("")), (( gdjs.Start_32ScreenCode.GDControllerCenterObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDControllerCenterObjects1[0].getPointY("")), "easeOutQuad", 700, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TouchRadius"), gdjs.Start_32ScreenCode.GDTouchRadiusObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDTouchRadiusObjects1Objects, runtimeScene, true, false);
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).setNumber(0);
}
{ //Subevents
gdjs.Start_32ScreenCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("TouchRadius"), gdjs.Start_32ScreenCode.GDTouchRadiusObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDTouchRadiusObjects1Objects, runtimeScene, true, true);
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Start_32ScreenCode.eventsList4(runtimeScene);} //End of subevents
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.Start_32ScreenCode.GDBackgroundObjects1);
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDBackgroundObjects1[i].setXOffset(gdjs.Start_32ScreenCode.GDBackgroundObjects1[i].getXOffset() + (100 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayButton"), gdjs.Start_32ScreenCode.GDPlayButtonObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i].isVisible() ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDPlayButtonObjects1[k] = gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length = k;}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.Start_32ScreenCode.GDScoreTextObjects1);
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDScoreTextObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDScoreTextObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayButton"), gdjs.Start_32ScreenCode.GDPlayButtonObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i].isVisible() ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDPlayButtonObjects1[k] = gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length = k;}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("AstroAnnie"), gdjs.Start_32ScreenCode.GDAstroAnnieObjects1);
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AstroAnnie"), gdjs.Start_32ScreenCode.GDAstroAnnieObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].isVisible() ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[k] = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length = k;}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDAstroAnnieObjects1 */
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].setAnimation(0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("PlayButton"), gdjs.Start_32ScreenCode.GDPlayButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayButtonHitBox"), gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDPlayButtonHitBoxObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Start_32ScreenCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i].getOpacity() == 255 ) {
        gdjs.Start_32ScreenCode.condition1IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDPlayButtonObjects1[k] = gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length = k;}}
if (gdjs.Start_32ScreenCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDPlayButtonObjects1 */
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i].setAnimation(1);
}
}
{ //Subevents
gdjs.Start_32ScreenCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayButtonHitBox"), gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDPlayButtonHitBoxObjects1Objects, runtimeScene, true, true);
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PlayButton"), gdjs.Start_32ScreenCode.GDPlayButtonObjects1);
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDPlayButtonObjects1[i].setAnimation(0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("AstroAnnie"), gdjs.Start_32ScreenCode.GDAstroAnnieObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].isVisible() ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[k] = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length = k;}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDAstroAnnieObjects1 */
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].addPolarForce(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) * 3, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AstroAnnie"), gdjs.Start_32ScreenCode.GDAstroAnnieObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fence"), gdjs.Start_32ScreenCode.GDFenceObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDAstroAnnieObjects1Objects, gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDFenceObjects1Objects, false, runtimeScene, false);
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDAstroAnnieObjects1 */
/* Reuse gdjs.Start_32ScreenCode.GDFenceObjects1 */
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].separateFromObjectsList(gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDFenceObjects1Objects, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("AstroAnnie"), gdjs.Start_32ScreenCode.GDAstroAnnieObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].isVisible() ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[k] = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length = k;}if ( gdjs.Start_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Fire") > 0.5;
}if ( gdjs.Start_32ScreenCode.condition1IsTrue_0.val ) {
{
{gdjs.Start_32ScreenCode.conditionTrue_1 = gdjs.Start_32ScreenCode.condition2IsTrue_0;
gdjs.Start_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8738212);
}
}}
}
if (gdjs.Start_32ScreenCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Fire");
}
{ //Subevents
gdjs.Start_32ScreenCode.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("ChocolateChip"), gdjs.Start_32ScreenCode.GDChocolateChipObjects1);
gdjs.copyArray(runtimeScene.getObjects("LargeCookieCluster"), gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1);
gdjs.copyArray(runtimeScene.getObjects("MediumCookieCluster"), gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1);
gdjs.copyArray(runtimeScene.getObjects("SmallCookieCluster"), gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1);
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1[i].addPolarForce(180, 50, 0);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1[i].addPolarForce(180, 100, 0);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1[i].addPolarForce(180, 150, 0);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1[i].rotate(10, runtimeScene);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1[i].rotate(30, runtimeScene);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1[i].rotate(50, runtimeScene);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDChocolateChipObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDChocolateChipObjects1[i].addPolarForce(180, 30, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AstroAnnie"), gdjs.Start_32ScreenCode.GDAstroAnnieObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].isVisible() ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[k] = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length = k;}if ( gdjs.Start_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "SpawnEnemy") > gdjs.random(1000);
}if ( gdjs.Start_32ScreenCode.condition1IsTrue_0.val ) {
{
{gdjs.Start_32ScreenCode.conditionTrue_1 = gdjs.Start_32ScreenCode.condition2IsTrue_0;
gdjs.Start_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7592140);
}
}}
}
if (gdjs.Start_32ScreenCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SpawnEnemy");
}
{ //Subevents
gdjs.Start_32ScreenCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("AstroAnnie"), gdjs.Start_32ScreenCode.GDAstroAnnieObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].isVisible() ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[k] = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length = k;}if ( gdjs.Start_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "SpawnEnemy2") > gdjs.random(500);
}if ( gdjs.Start_32ScreenCode.condition1IsTrue_0.val ) {
{
{gdjs.Start_32ScreenCode.conditionTrue_1 = gdjs.Start_32ScreenCode.condition2IsTrue_0;
gdjs.Start_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8711972);
}
}}
}
if (gdjs.Start_32ScreenCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SpawnEnemy2");
}
{ //Subevents
gdjs.Start_32ScreenCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("AstroAnnie"), gdjs.Start_32ScreenCode.GDAstroAnnieObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].isVisible() ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[k] = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length = k;}if ( gdjs.Start_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "SpawnEnemy3") > gdjs.random(200);
}if ( gdjs.Start_32ScreenCode.condition1IsTrue_0.val ) {
{
{gdjs.Start_32ScreenCode.conditionTrue_1 = gdjs.Start_32ScreenCode.condition2IsTrue_0;
gdjs.Start_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8643396);
}
}}
}
if (gdjs.Start_32ScreenCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SpawnEnemy3");
}
{ //Subevents
gdjs.Start_32ScreenCode.eventsList9(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("LargeCookieCluster"), gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1);
gdjs.copyArray(runtimeScene.getObjects("MediumCookieCluster"), gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Shot"), gdjs.Start_32ScreenCode.GDShotObjects1);
gdjs.copyArray(runtimeScene.getObjects("SmallCookieCluster"), gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDLargeCookieClusterObjects1ObjectsGDgdjs_46Start_9532ScreenCode_46GDMediumCookieClusterObjects1ObjectsGDgdjs_46Start_9532ScreenCode_46GDSmallCookieClusterObjects1Objects, gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDShotObjects1Objects, false, runtimeScene, false);
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1 */
/* Reuse gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1 */
/* Reuse gdjs.Start_32ScreenCode.GDShotObjects1 */
/* Reuse gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1 */
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDShotObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDShotObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1[i].getBehavior("Health").Hit(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "RockDamaged.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LargeCookieCluster"), gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1);
gdjs.copyArray(runtimeScene.getObjects("MediumCookieCluster"), gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1);
gdjs.copyArray(runtimeScene.getObjects("SmallCookieCluster"), gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1[k] = gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1.length = k;for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1[k] = gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1.length = k;for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1[k] = gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length = k;}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1 */
/* Reuse gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1 */
/* Reuse gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1 */
gdjs.Start_32ScreenCode.GDDestroyedMeteorObjects1.length = 0;

{for(var i = 0, len = gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "DestroyedRock.wav", false, 50, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDDestroyedMeteorObjects1Objects, (( gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1[0].getPointX("")) :gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1[0].getPointX("")) :gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1[0].getPointX("")), (( gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1.length === 0 ) ? (( gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1[0].getPointY("")) :gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1[0].getPointY("")) :gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1[0].getPointY("")), "");
}
{ //Subevents
gdjs.Start_32ScreenCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("AstroAnnie"), gdjs.Start_32ScreenCode.GDAstroAnnieObjects1);
gdjs.copyArray(runtimeScene.getObjects("LargeCookieCluster"), gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1);
gdjs.copyArray(runtimeScene.getObjects("MediumCookieCluster"), gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1);
gdjs.copyArray(runtimeScene.getObjects("SmallCookieCluster"), gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDAstroAnnieObjects1Objects, gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDLargeCookieClusterObjects1ObjectsGDgdjs_46Start_9532ScreenCode_46GDMediumCookieClusterObjects1ObjectsGDgdjs_46Start_9532ScreenCode_46GDSmallCookieClusterObjects1Objects, false, runtimeScene, false);
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDAstroAnnieObjects1 */
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].getBehavior("Health").Hit(100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AstroAnnie"), gdjs.Start_32ScreenCode.GDAstroAnnieObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Start_32ScreenCode.condition0IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[k] = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length = k;}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDAstroAnnieObjects1 */
gdjs.copyArray(runtimeScene.getObjects("GameOverText"), gdjs.Start_32ScreenCode.GDGameOverTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("RetryButton"), gdjs.Start_32ScreenCode.GDRetryButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.Start_32ScreenCode.GDScoreTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("ScoreTweenTarget"), gdjs.Start_32ScreenCode.GDScoreTweenTargetObjects1);
gdjs.Start_32ScreenCode.GDDeathEffectObjects1.length = 0;

{for(var i = 0, len = gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Defeated.wav", false, 50, 1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "GameOverCry.ogg", false, 50, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDDeathEffectObjects1Objects, (( gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[0].getPointX("")), (( gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDAstroAnnieObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDRetryButtonObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDRetryButtonObjects1[i].getBehavior("Tween").addObjectOpacityTween("RetryFadeStart", 255, "easeInOutQuad", 3000, false);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDGameOverTextObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDGameOverTextObjects1[i].getBehavior("Tween").addObjectOpacityTween("GameOverFadeStart", 255, "easeInOutQuad", 3000, false);
}
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDScoreTextObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDScoreTextObjects1[i].getBehavior("Tween").addObjectPositionTween("ScoreTweenStart", (( gdjs.Start_32ScreenCode.GDScoreTweenTargetObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDScoreTweenTargetObjects1[0].getPointX("")), (( gdjs.Start_32ScreenCode.GDScoreTweenTargetObjects1.length === 0 ) ? 0 :gdjs.Start_32ScreenCode.GDScoreTweenTargetObjects1[0].getPointY("")), "easeInOutQuad", 2000, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("PlayButtonHitBox"), gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("RetryButton"), gdjs.Start_32ScreenCode.GDRetryButtonObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDPlayButtonHitBoxObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Start_32ScreenCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.Start_32ScreenCode.GDRetryButtonObjects1.length;i<l;++i) {
    if ( gdjs.Start_32ScreenCode.GDRetryButtonObjects1[i].getOpacity() == 255 ) {
        gdjs.Start_32ScreenCode.condition1IsTrue_0.val = true;
        gdjs.Start_32ScreenCode.GDRetryButtonObjects1[k] = gdjs.Start_32ScreenCode.GDRetryButtonObjects1[i];
        ++k;
    }
}
gdjs.Start_32ScreenCode.GDRetryButtonObjects1.length = k;}}
if (gdjs.Start_32ScreenCode.condition1IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDRetryButtonObjects1 */
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDRetryButtonObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDRetryButtonObjects1[i].setAnimation(1);
}
}
{ //Subevents
gdjs.Start_32ScreenCode.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayButtonHitBox"), gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDPlayButtonHitBoxObjects1Objects, runtimeScene, true, true);
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("RetryButton"), gdjs.Start_32ScreenCode.GDRetryButtonObjects1);
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDRetryButtonObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDRetryButtonObjects1[i].setAnimation(0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SoundButton"), gdjs.Start_32ScreenCode.GDSoundButtonObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = false;
gdjs.Start_32ScreenCode.condition2IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Start_32ScreenCode.condition0IsTrue_0.val ) {
{
gdjs.Start_32ScreenCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDSoundButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Start_32ScreenCode.condition1IsTrue_0.val ) {
{
{gdjs.Start_32ScreenCode.conditionTrue_1 = gdjs.Start_32ScreenCode.condition2IsTrue_0;
gdjs.Start_32ScreenCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8516004);
}
}}
}
if (gdjs.Start_32ScreenCode.condition2IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDSoundButtonObjects1 */
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDSoundButtonObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDSoundButtonObjects1[i].toggleVariableBoolean(gdjs.Start_32ScreenCode.GDSoundButtonObjects1[i].getVariables().getFromIndex(0));
}
}
{ //Subevents
gdjs.Start_32ScreenCode.eventsList12(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("AstroAnnie"), gdjs.Start_32ScreenCode.GDAstroAnnieObjects1);
gdjs.copyArray(runtimeScene.getObjects("ChocolateChip"), gdjs.Start_32ScreenCode.GDChocolateChipObjects1);

gdjs.Start_32ScreenCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32ScreenCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDAstroAnnieObjects1Objects, gdjs.Start_32ScreenCode.mapOfGDgdjs_46Start_9532ScreenCode_46GDChocolateChipObjects1Objects, false, runtimeScene, false);
}if (gdjs.Start_32ScreenCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Start_32ScreenCode.GDChocolateChipObjects1 */
{runtimeScene.getVariables().getFromIndex(4).add(1);
}{for(var i = 0, len = gdjs.Start_32ScreenCode.GDChocolateChipObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDChocolateChipObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "CollectChocolate.wav", false, 50, 1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.Start_32ScreenCode.GDScoreTextObjects1);
{for(var i = 0, len = gdjs.Start_32ScreenCode.GDScoreTextObjects1.length ;i < len;++i) {
    gdjs.Start_32ScreenCode.GDScoreTextObjects1[i].setString("Score: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4))));
}
}}

}


};

gdjs.Start_32ScreenCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Start_32ScreenCode.GDBackgroundObjects1.length = 0;
gdjs.Start_32ScreenCode.GDBackgroundObjects2.length = 0;
gdjs.Start_32ScreenCode.GDBackgroundObjects3.length = 0;
gdjs.Start_32ScreenCode.GDGameOverTextObjects1.length = 0;
gdjs.Start_32ScreenCode.GDGameOverTextObjects2.length = 0;
gdjs.Start_32ScreenCode.GDGameOverTextObjects3.length = 0;
gdjs.Start_32ScreenCode.GDAstroAnnieObjects1.length = 0;
gdjs.Start_32ScreenCode.GDAstroAnnieObjects2.length = 0;
gdjs.Start_32ScreenCode.GDAstroAnnieObjects3.length = 0;
gdjs.Start_32ScreenCode.GDTitleScreenObjects1.length = 0;
gdjs.Start_32ScreenCode.GDTitleScreenObjects2.length = 0;
gdjs.Start_32ScreenCode.GDTitleScreenObjects3.length = 0;
gdjs.Start_32ScreenCode.GDPlayButtonObjects1.length = 0;
gdjs.Start_32ScreenCode.GDPlayButtonObjects2.length = 0;
gdjs.Start_32ScreenCode.GDPlayButtonObjects3.length = 0;
gdjs.Start_32ScreenCode.GDShotObjects1.length = 0;
gdjs.Start_32ScreenCode.GDShotObjects2.length = 0;
gdjs.Start_32ScreenCode.GDShotObjects3.length = 0;
gdjs.Start_32ScreenCode.GDControllerCenterObjects1.length = 0;
gdjs.Start_32ScreenCode.GDControllerCenterObjects2.length = 0;
gdjs.Start_32ScreenCode.GDControllerCenterObjects3.length = 0;
gdjs.Start_32ScreenCode.GDControllerPositionObjects1.length = 0;
gdjs.Start_32ScreenCode.GDControllerPositionObjects2.length = 0;
gdjs.Start_32ScreenCode.GDControllerPositionObjects3.length = 0;
gdjs.Start_32ScreenCode.GDTouchRadiusObjects1.length = 0;
gdjs.Start_32ScreenCode.GDTouchRadiusObjects2.length = 0;
gdjs.Start_32ScreenCode.GDTouchRadiusObjects3.length = 0;
gdjs.Start_32ScreenCode.GDScoreTextObjects1.length = 0;
gdjs.Start_32ScreenCode.GDScoreTextObjects2.length = 0;
gdjs.Start_32ScreenCode.GDScoreTextObjects3.length = 0;
gdjs.Start_32ScreenCode.GDMouseDistanceCheckObjects1.length = 0;
gdjs.Start_32ScreenCode.GDMouseDistanceCheckObjects2.length = 0;
gdjs.Start_32ScreenCode.GDMouseDistanceCheckObjects3.length = 0;
gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects1.length = 0;
gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects2.length = 0;
gdjs.Start_32ScreenCode.GDPlayButtonHitBoxObjects3.length = 0;
gdjs.Start_32ScreenCode.GDFenceObjects1.length = 0;
gdjs.Start_32ScreenCode.GDFenceObjects2.length = 0;
gdjs.Start_32ScreenCode.GDFenceObjects3.length = 0;
gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects1.length = 0;
gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects2.length = 0;
gdjs.Start_32ScreenCode.GDLargeCookieClusterObjects3.length = 0;
gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects1.length = 0;
gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects2.length = 0;
gdjs.Start_32ScreenCode.GDMediumCookieClusterObjects3.length = 0;
gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects1.length = 0;
gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects2.length = 0;
gdjs.Start_32ScreenCode.GDSmallCookieClusterObjects3.length = 0;
gdjs.Start_32ScreenCode.GDScoreTweenTargetObjects1.length = 0;
gdjs.Start_32ScreenCode.GDScoreTweenTargetObjects2.length = 0;
gdjs.Start_32ScreenCode.GDScoreTweenTargetObjects3.length = 0;
gdjs.Start_32ScreenCode.GDDestroyedMeteorObjects1.length = 0;
gdjs.Start_32ScreenCode.GDDestroyedMeteorObjects2.length = 0;
gdjs.Start_32ScreenCode.GDDestroyedMeteorObjects3.length = 0;
gdjs.Start_32ScreenCode.GDSoundButtonObjects1.length = 0;
gdjs.Start_32ScreenCode.GDSoundButtonObjects2.length = 0;
gdjs.Start_32ScreenCode.GDSoundButtonObjects3.length = 0;
gdjs.Start_32ScreenCode.GDAnneSpawnPointObjects1.length = 0;
gdjs.Start_32ScreenCode.GDAnneSpawnPointObjects2.length = 0;
gdjs.Start_32ScreenCode.GDAnneSpawnPointObjects3.length = 0;
gdjs.Start_32ScreenCode.GDRetryButtonObjects1.length = 0;
gdjs.Start_32ScreenCode.GDRetryButtonObjects2.length = 0;
gdjs.Start_32ScreenCode.GDRetryButtonObjects3.length = 0;
gdjs.Start_32ScreenCode.GDChocolateChipObjects1.length = 0;
gdjs.Start_32ScreenCode.GDChocolateChipObjects2.length = 0;
gdjs.Start_32ScreenCode.GDChocolateChipObjects3.length = 0;
gdjs.Start_32ScreenCode.GDDeathEffectObjects1.length = 0;
gdjs.Start_32ScreenCode.GDDeathEffectObjects2.length = 0;
gdjs.Start_32ScreenCode.GDDeathEffectObjects3.length = 0;

gdjs.Start_32ScreenCode.eventsList13(runtimeScene);
return;

}

gdjs['Start_32ScreenCode'] = gdjs.Start_32ScreenCode;
